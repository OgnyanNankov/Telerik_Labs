## Variables and Data Types

### 1. What are variables?

Variables are named values that can store any type of JavaScript data before and after processing it. To sum  up, variables are containers for storing data. 

### 2. What data types are there in JavaScript? Provide examples for each type.

A data type is an attribute associated with a piece of data that tells a computer system how to interpret its value
- Primitive types: **number (let n = 123;), string (let str = "Hello";), boolean (let nameFieldChecked = true;), bigInt (const bigInt = 1234567890123456789012345678901234567890n;), null (let age = null;), undefined (let age;), symbol**
- Reference types: **objects, functions**





